echo -e "this is first add without -a" | ./ex2 ex2.txt
echo -e "this is second add with -a" | ./ex2 -a ex2.txt
